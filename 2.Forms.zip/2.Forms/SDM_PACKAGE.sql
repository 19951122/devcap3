CREATE OR REPLACE PACKAGE BODY lab04test_pkg
AS
PROCEDURE lab04training (
errbuf OUT VARCHAR2,
retcode OUT NUMBER)
AS
BEGIN
fnd_file.put_line (fnd_file.output,
'in output file' );
fnd_file.put_line (fnd_file.log, 'in log file');
END lab04training;
END lab04test_pkg;
/
