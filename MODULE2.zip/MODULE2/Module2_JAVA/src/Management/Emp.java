package Management;

public class Emp {

	public static void main(String[] args) {
		Manager m;
		m = new Manager("Deva", 5, 30000, "Hardware");
		m.dispSal();
		
		m = new Employee("Martin", 2, 25000, "Software");
		m.dispSal();

	}

}
