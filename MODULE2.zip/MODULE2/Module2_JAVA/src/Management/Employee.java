package Management;

class Employee extends Manager {

	public Employee(String name, int exp, int baseSal, String dept) {
		super(name, exp, baseSal, dept);
	}
	
	//returns the sal 
	public int calcEmpSalary(){
		int salary = (this.calcMgrSalary() + 100);
		return salary;
	}
	
	//prints the sal
	
	public void dispSal(){
		System.out.println("Employee Salary :" + calcEmpSalary());
	}

}
