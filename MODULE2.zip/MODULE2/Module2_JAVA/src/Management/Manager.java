package Management;

public class Manager {String name;
int exp = 0; 		
int baseSal = 100;		
String domain;
public Manager(String name, int exp, int baseSal, String domain) {
	this.name = name;
	if(exp >= 0 && baseSal > 0){
		this.exp = exp;
		this.baseSal = baseSal;
	}
	this.domain = domain;
}

public int calcMgrSalary(){
	int sal;
	sal = baseSal + (5 * exp);
	return sal;
}

public void dispSal(){
	System.out.println("Manager Salary :" + calcMgrSalary());
}

}



