
public class Person {
	
	public String first,last,gender;
	public int age;
	public double weight;
	

	public Person(String first, String last, String gender, int age,
			double weight) {
		this.first = first;
		this.last = last;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}


	public static void main(String[] args) {
		

	}

}
