

public class Positive {

	public static void main(String[] args) {
	
		int a;
		a=Integer.parseInt(args[0]);
		if(a>=0)
				System.out.println(" Number is Positive");
		else
			System.out.println("The number is Negative");
		
	}

}
